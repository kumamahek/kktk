
import React, { useEffect, useRef } from "react";
import { DataSet, Network } from "vis-network/standalone";

const nodeDetails = {
  A: { label: "SOO: A", title: "Level 1" },
  "1": { label: "Downstream 1", title: "Level 2" },
  "2": { label: "Downstream 2", title: "Level 2" },
  "1.1": { label: "Unit 1", title: "Level 3" },
  "1.2": { label: "Unit 2", title: "Level 3" },
  "2.1": { label: "Product A", title: "Level 3" },
  "1.1.1": { label: "Rule 1", title: "Level 4" },
  "1.2.1": { label: "Rule 2", title: "Level 4" },
  "1.2.2": { label: "Rule 3", title: "Level 4" },
};

const allLevels = {
  A: ["1", "2"],
  "1": ["1.1", "1.2"],
  "2": ["2.1"],
  "1.1": ["1.1.1"],
  "1.2": ["1.2.1", "1.2.2"]
};

const App = () => {
  const networkRef = useRef(null);
  const nodes = useRef(new DataSet());
  const edges = useRef(new DataSet());
  const expanded = useRef(new Set());
  const currentLayout = useRef("UD");

  const drawNetwork = () => {
    const data = {
      nodes: nodes.current,
      edges: edges.current,
    };

    const options = {
      layout: {
        hierarchical: {
          direction: currentLayout.current,
          sortMethod: "directed",
          levelSeparation: 100,
          nodeSpacing: 200
        }
      },
      nodes: {
        shape: "box",
        font: { size: 16 },
      },
      edges: {
        arrows: "to",
        smooth: { type: "cubicBezier" }
      },
      interaction: { hover: true },
      physics: false
    };

    new Network(networkRef.current, data, options).on("click", function (params) {
      const nodeId = params.nodes[0];
      if (nodeId && !expanded.current.has(nodeId)) {
        expandNode(nodeId);
      }
    });
  };

  const expandNode = (nodeId) => {
    const children = allLevels[nodeId] || [];
    children.forEach((childId) => {
      if (!nodes.current.get(childId)) {
        nodes.current.add({ id: childId, ...nodeDetails[childId] });
      }
      if (!edges.current.get({ filter: e => e.from === nodeId && e.to === childId }).length) {
        edges.current.add({ from: nodeId, to: childId });
      }
    });
    expanded.current.add(nodeId);
  };

  const resetGraph = () => {
    nodes.current.clear();
    edges.current.clear();
    expanded.current.clear();
    nodes.current.add({ id: "A", ...nodeDetails["A"] });
    drawNetwork();
  };

  const expandAll = () => {
    Object.keys(allLevels).forEach(expandNode);
  };

  const toggleLayout = () => {
    currentLayout.current = currentLayout.current === "UD" ? "LR" : "UD";
    drawNetwork();
  };

  useEffect(() => {
    resetGraph();
  }, []);

  return (
    <div>
      <div style={{ padding: "10px", background: "#eee" }}>
        <button onClick={expandAll}>Expand All</button>
        <button onClick={resetGraph}>Reset</button>
        <button onClick={toggleLayout}>Toggle Layout</button>
      </div>
      <div ref={networkRef} style={{ height: "90vh" }} />
    </div>
  );
};

export default App;
